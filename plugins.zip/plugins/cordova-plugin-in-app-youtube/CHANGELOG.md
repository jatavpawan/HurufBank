# v1.0.1 (2017-06-05)

## Fixes

- Added `LICENSE` file.
- Changes `js` pygments suggestion to `html` inside `README.md`.
- Removed trailing comma inside `package.json` causing Cordova 7.0.1 to crash on plugin install.

# v1.0.0 (2017-04-04)

First release.
