#import <Cordova/CDVPlugin.h>

@interface InAppYouTube : CDVPlugin {
}

- (void)openVideo:(CDVInvokedUrlCommand *)command;

@end
